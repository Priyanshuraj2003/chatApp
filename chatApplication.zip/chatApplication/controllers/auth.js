import { create, findOne } from "../models/User.js";
import { hash as _hash, compare } from "bcryptjs";
import { sign } from "jsonwebtoken";

export async function register(req, res) {
  const { username, password } = req.body;
  const hash = await _hash(password, 10);
  try {
    const user = await create({ username, password: hash });
    res.status(201).json(user);
  } catch {
    res.status(400).json({ error: "Username taken" });
  }
}

export async function login(req, res) {
  const { username, password } = req.body;
  const user = await findOne({ username });
  if (user && await compare(password, user.password)) {
    const token = sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "1d" });
    res.json({ token, userId: user._id });
  } else {
    res.status(401).json({ error: "Invalid credentials" });
  }
}
