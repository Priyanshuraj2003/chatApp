// routes/message.js

import { Router } from "express";
import Message from "../models/Message.js";
import auth from "../middleware/auth.js";

const router = Router();

// POST /api/messages
router.post("/", auth, async (req, res) => {
  const { content } = req.body;
  const sender = req.user.id;

  try {
    const message = new Message({
      sender,
      content,
    });
    await message.save();
    res.status(201).json(message);
  } catch (err) {
    console.error("Message save error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// GET /api/messages
router.get("/", auth, async (req, res) => {
  try {
    const messages = await Message.find().populate("sender", "username");
    res.json(messages);
  } catch (err) {
    console.error("Fetch error:", err);
    res.status(500).json({ error: "Server error" });
  }
});

export default router;
