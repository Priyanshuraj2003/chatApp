import express, { json } from "express";
import { connect } from "mongoose";
import { config } from "dotenv";
import cors from "cors";
import { createServer } from "http";
import { Server } from "socket.io";

import authRoutes from "./routes/auth.js";
import messageRoutes from "./routes/message.js"; // assuming you have this

import authMiddleware from "./middleware/auth.js"; // JWT middleware
import Message from "./models/Message.js"; // Message model

config();
console.log("JWT_SECRET:", process.env.JWT_SECRET);


const app = express();
const server = createServer(app); // 👈 Important: Create HTTP server
//Run this to test if the server actually responds:
app.get("/api/ping", (req, res) => {
  res.send("pong");
});

// 🔒 Apply CORS to Express
app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(json());

// 🔌 Routes
app.use("/api/auth", authRoutes);
app.use("/api/messages", messageRoutes); // GET and POST messages

// 🔌 Socket.IO setup
const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000", // Frontend origin
    methods: ["GET", "POST"],
  },
});

import pkg from "jsonwebtoken";
const { verify } = pkg;



io.use((socket, next) => {
console.log("Socket handshake auth token:", socket.handshake.auth.token);
const token = socket.handshake.auth.token;
if (!token) {
  console.log("No token provided in handshake");
  return next(new Error("Authentication error"));
}

  try {
    const decoded = verify(token, process.env.JWT_SECRET);
    socket.user = decoded; 
    next();
  } catch (err) {
     console.log("JWT verify error:", err.message);
    next(new Error("Authentication error"));
  }
});


io.on("connection", (socket) => {
  console.log("A user connected:", socket.user.id);

  socket.on("send message", async ({ content }) => {
    const message = new Message({ sender: socket.user.id, content });
    await message.save();
    io.emit("message", message); // broadcast to all
  });

  socket.on("disconnect", () => {
    console.log("User disconnected");
  });
});

// MongoDB connection
connect(process.env.MONGO_URI)
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("MongoDB connection error:", err));

// 🔥 Start the server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
